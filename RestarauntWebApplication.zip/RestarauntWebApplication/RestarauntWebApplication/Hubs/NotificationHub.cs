﻿using Microsoft.AspNetCore.SignalR;
using RestarauntWebApplication.Models.EFModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace RestarauntWebApplication.Hubs
{
    public class NotificationHub : Hub
    {

    }
}
