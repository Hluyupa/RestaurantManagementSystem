﻿using RestarauntWebApplication.Models.EFModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestarauntWebApplication.Models
{
    public class DishCookOrderUpdateModel
    {
        public DishCookOrder DishCookOrder { get; set; }
        public string Login { get; set; }
    }
}
