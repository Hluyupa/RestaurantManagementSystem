﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestarauntWebApplication.Models.ViewModels
{
    public class DishView
    {
        public string Name { get; set; }
        public decimal Cost { get; set; }
        public string Type { get; set; }
    }
}
