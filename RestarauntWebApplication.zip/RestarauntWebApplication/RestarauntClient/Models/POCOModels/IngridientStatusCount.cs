﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestarauntClient.Models.POCOModels
{
    public class IngridientStatusCount
    {
        public Ingridient Ingridient { get; set; }
        public string StatusOfCount{ get; set; }
    }
}
