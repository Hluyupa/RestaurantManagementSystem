﻿using RestarauntClient.Models.POCOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestarauntClient.Models
{
    public class AddIngridientsStorageModel
    {
        public Ingridient Ingridient { get; set; }
        public int IngridientQuantity { get; set; }
    }
}
