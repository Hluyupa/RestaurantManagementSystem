﻿using RestarauntClient.Models.POCOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestarauntClient.Models
{
    public class DishCookOrderUpdateModel
    {
        public DishCookOrder DishCookOrder { get; set; }
        public string Login { get; set; }
    }
}
